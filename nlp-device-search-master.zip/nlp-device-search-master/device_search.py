import requests
import json
from flask_login import (
    current_user,
    login_required
)
from flask import g
# log = Config.getLogger()


def form_url(query,isText):
    url_ds="http://device-search-svc.central.svc.cluster.local:80" 

    if(not isText):
        Url = "/device-search/internal/v1/devices?query="
        Url =url_ds + Url + query
        print("url...",Url)
    else:
        Url =url_ds + "/device-search/internal/v2/devices"
    return Url

def construct_json_input(entity_list):
    json.dumps(entity_list)


def invoke_device_search_v1(query,isText):
    url_ds = form_url(query,isText)
    headers = dict()
    headers['X-Device-Search-Customer'] = "6964b7bcec1947d9ad425d77e61ba0cb"
    print("Calling device search")
    # url_ds="http://device-search-svc.central.svc.cluster.local:80" + URL
    # print(url_ds)
    try:
        resp=requests.get(url_ds,headers=headers)
        print("response...",resp)
        # log.info("response from device search")
        # log.info(resp)
    except:
        print("Exception")
        # log.info("exception request1")
    if resp.status_code is not 200:
        # log.error("Unable to fetch interface details for given cid:{}. Error:{}".format(cid, resp))
        # log.error(traceback.format_exc())
        print("unable to fetch")
    else:
        resp_json = json.loads(resp.content)
        # log.info(resp_json)
        return resp_json

    return None




def invoke_device_search_v2(final_entity_map,isText):
    print("in v2")
    url_ds = form_url(None,isText)
    headers = dict()
    headers = {
    'X-Device-Search-Customer': '6964b7bcec1947d9ad425d77e61ba0cb',
    'Content-Type': 'application/json',
    }
    print("Calling device search")
    # url_ds="http://device-search-svc.central.svc.cluster.local:80" + URL
    print('input url',url_ds)
    print('data',final_entity_map)
    # input_data=construct_json_input(entity_list)
    try:
        print("hereee in res")
        resp=requests.get(url_ds,headers=headers,data=final_entity_map)
        print("response...",resp)
        # log.info("response from device search")
        # log.info(resp)
    except:
        print("Exception")
        # log.info("exception request1")
        if resp.status_code !=200:
            # log.error("Unable to fetch interface details for given cid:{}. Error:{}".format(cid, resp))
            # log.error(traceback.format_exc())
            print("unable to fetch")
    else:
        resp_json = json.loads(resp.content)
        # log.info(resp_json)
        # return resp.text
        return resp_json

    return None


def invoke_device_search_v1_direct(lucene_query):
    headers = dict()
    headers['X-Device-Search-Customer'] = "6964b7bcec1947d9ad425d77e61ba0cb"
    print("Calling device search")
    url_ds="http://device-search-svc.central.svc.cluster.local:80/device-search/internal/v1/devices?query="
    url_ds=url_ds+lucene_query
    
    # print(url_ds)
    try:
        resp=requests.get(url_ds,headers=headers)
        print("response...",resp)
        # log.info("response from device search")
        # log.info(resp)
    except:
        print("Exception")
        # log.info("exception request1")
    if resp.status_code is not 200:
        # log.error("Unable to fetch interface details for given cid:{}. Error:{}".format(cid, resp))
        # log.error(traceback.format_exc())
        print("unable to fetch")
    else:
        resp_json = json.loads(resp.content)
        # log.info(resp_json)
        return resp_json

    return None
