import requests
import json
from flask import Flask
from flask import request
import os
import watson_api as assistant
import validate_query as validate
import query_builder as query_builder
import configparser as ConfigParser
import searchquery
import device_search
# from jupiter.logger import logging
import logging
from flask import Response
from parse_boolean_relation import parse_boolean,construct_lucene_query





config = ConfigParser.ConfigParser()
# config.read('/home/config.ini')

config.read('/ws/datarp/nlpdevicesearch/config.ini')



app = Flask(__name__)
# app.config["LOG_TYPE"] = os.environ.get("LOG_TYPE", "stream")
# app.config["LOG_LEVEL"] = os.environ.get("LOG_LEVEL", "INFO")

logging.basicConfig(level=logging.INFO)


def checkTextInput(query):
    isText = True
    #validate queries
    if(":" in query):
        isLucene = validate.validateLuceneQuery(query)
        isText = not isLucene
        return isText
    return isText


"""
Extract regex based entities
"""
def extract_regex_entities(entities, user_input):

    # stop_word_list = list(get_stop_words('english'))
    # Extend the stopwords with common terms used in search queries
    stop_word_list =[]
    stop_word_list.extend(('name', 'number', 'no', 'num', 'status', 'issue', 'issues', 'having', 'info', 'information', 'detail', 'details',\
                            'list', 'show', 'model', 'serial', 'anomalies', 'problems', 'failures', 'anomaly', 'problem', 'failure'))

    entity_key_values = {}
    for item in entities:
        if 'groups' in item and item['groups'] != None and len(item['groups'])>1:
            # Extract the values from group 1
            group = item['groups'][1]
            if 'location' in group:
                reg_value = user_input[group['location'][0]:group['location'][1]]

                entity_value = reg_value
                if len(reg_value) > 0 and reg_value[len(reg_value)-1] == " ":
                    entity_value = entity_value[:len(reg_value)-1]

                # Check stopwords are quoted. Else skip the extraction.
                if reg_value[0] != '\"'  and reg_value[len(reg_value)-1] != '\"' \
                            and entity_value.lower() in stop_word_list:
                    continue

                if item['entity'] not in entity_key_values:
                    entity_key_values[item['entity']] = []
                entity_key_values[item['entity']].append({\
                                                        'value' : entity_value,\
                                                        'confidence' : item['confidence']\
                                                        })

    print('Matched Regex Entities : {}'.format(entity_key_values))
    print()

    return entity_key_values



def process_boolean_operators(inputText, entities,keywords):
    entity_list=[]


    if "OR" in inputText:
        print("OR query")
        input_parts=inputText.split("OR")
        print(input_parts)
        for part in input_parts:
            temp=[]
            for entity in keywords:
                print(entity," part", part)
                if entity in part:
                    temp.append(entity)
            if len(temp)>0: 
                entity_list.append(temp)
    print("listtt...",entity_list)
    return entity_list





@app.route("/nlpsearchquery")
def search():
    # print("request",request)
    # print("checklog")
    # app.logger.info("This is an info message")

    # print("json...",request.get_json())
    query=request.get_json()['input']
    print(query)

    text_search = checkTextInput(query)
    print("is text",text_search)

    if(text_search):
        #call to watson api
        assist_response = json.loads(assistant.get_assistant_response(query))

        #write code to read data from dispatcher 

        if 'intents' in assist_response:
            print("key present")

        intents = assist_response["intents"]
        print("intetns")
        print(assist_response['intents'])
        filtered_intents =[]
        if intents!=None and len(intents)>0:
            for intent in intents:
                if intent['confidence'] > float(config.get('ASSISTANT','CONFIDENCE_THRESHOLD')):
                    filtered_intents.append(intent)
        
        entities = assist_response['entities']

        regex_entities = extract_regex_entities(entities,query)
        print(type(regex_entities))
        # entities.update(regex_entities)
        entity_key_values = {}
        for item in entities:
            print("item",item)
            if item['confidence'] > 0.7:
                if item['entity'] not in entity_key_values:
                    entity_key_values[item['entity']] = []
            
                entity_key_values[item['entity']].append({\
                                                            'value' : item['value'],\
                                                            'confidence' : item['confidence']
                                                            })
        for key,value in regex_entities.items():
            print("item",item)
            for item in regex_entities[key]:
                if item['confidence'] > 0.7:
                    if key not in entity_key_values:
                        entity_key_values[item] = []
            
                    entity_key_values[key]=[{\
                                                            'value' : item['value'],\
                                                            'confidence' : item['confidence']
                                                            }]
        print("entities")                                                
        print(entity_key_values)

        #to do: read filter entities from dispatcher
        filter_entites = ['running-config','ip-address','model','firmware-version','serial','group','status','mac-address']

        print("keys",entity_key_values.keys())



        final_entities = { key: entity_key_values[key] for key in filter_entites if key in entity_key_values.keys() }

        print("final entities extracted",final_entities)

        # for ent in final_entities:
        #     res = searchquery.es_search(final_entities[ent][0]['value'])
        #     print(res)
        entity_list=[]
        keywords=[]
        entity_name_value_map={}
        for ent in final_entities:
            print("entity = ",ent)
            for value in final_entities[ent]:
                keywords.append(value['value'])
                entity_name_value_map[value['value']]=ent

        print(entity_name_value_map)

        parsed_query = parse_boolean(query,keywords)
        print("Parsed Query is...",parsed_query)

        lucene_query = construct_lucene_query(parsed_query,keywords,entity_name_value_map)

        print("constructed lucene query...",lucene_query)


        # if "OR" in query:
        #     entity_list = process_boolean_operators(query,final_entities,keywords)
        # else:
        #     entity_list= [keywords]

        # print("final entity list...",entity_list, 'json',json.dumps(entity_list))
        # final_entity_list=[]
        # for entry in entity_list:
        #     temp_map={}
        #     temp_map['entity']=entry
        #     final_entity_list.append(temp_map)
        
        # print("map...",final_entity_list,"to json...",json.dumps(final_entity_list))

        # final_entity_map={}
        # final_entity_map["entity_list"]=final_entity_list
        # final_entity_map["operator"]="OK"
        
        # es_response = query_builder.build_search_query(final_entities)
        # res = device_search.invoke_device_search_v2(json.dumps(final_entity_map),text_search)
        res = device_search.invoke_device_search_v1_direct(lucene_query)


        print(res)
        # return json.dumps(res) 
        # return res
        return Response(json.dumps(res),  mimetype='application/json')


    else:
        #call to existing device search api
        res = device_search.invoke_device_search_v1(query,text_search)
        print(res)
        # return json.dumps(res)
        return Response(json.dumps(res),  mimetype='application/json')


        
if __name__ == "__main__":
    app.run(host='0.0.0.0')
