
import nltk

import spacy



def parse_boolean(sentence, entities):
    nlp = spacy.load("en_core_web_sm")
    # nlp = spacy.load('/ws/datarp/aisearch/spacy/search_model')

    # sentence="List all switches with configuration vlan 100  and ip 10.180.5.232 except with ospf,bgp configured"
    # sentence="all switches except ospf configured"

    # sentence="switches with model 8400 not having network address ip 10.180.5.232 and config ospf"


    negation_mapper={'except':'not','without':'not','neither':'not','nor':'not'}

    # entities=['vlan 100','ospf','10.180.5.232','bgp','8400']
    filter_entities=[]
    print("orig sentence",sentence)
    for entity in entities:
        temp=entity
        entity=entity.replace(" ","")

        print(temp," ",entity)
        sentence=sentence.replace(temp,entity)
        filter_entities.append(entity)

    for word in sentence.split(" "):
        if word in negation_mapper.keys():
            sentence=sentence.replace(word,negation_mapper[word])

    print("sentence",sentence)
    print(filter_entities)


    entity_maps=dict(zip(filter_entities,entities))

    for item in entity_maps:
        print(item)
    text = ""
    textss  = []

    doc = nlp(sentence) 


    for tok in doc: 
        print(tok.text, "-->",tok.dep_, "-->",tok.pos_)

        if tok.pos_ in ['CCONJ'] or tok.dep_ in ['neg'] or tok.text in filter_entities:
            print(tok.text, "-->",tok.dep_, "-->",tok.pos_)
            sentence = (tok.text ,tok.pos_)
            textss.append(sentence)
            text = text +" " + tok.text

    print("text....",text)


    for word in text.split(" "):
        if(word in entity_maps.keys()):
            text=text.replace(word,entity_maps[word])


    print("updated text",text)
    return text




def construct_lucene_query(text,entities,entity_mappings):
    print(text)
    print(entities)
    print(entity_mappings)

    temp=""
    lucene_query=""

    for token in text.split(" "):
        print("token= ",token," temp= ",temp)
        if temp!="":
            token=temp +" "+ token

        if(token!=None and token!=" " and token!=""  and token not in ['and','AND','or','OR','NOT','not'] and token in entity_mappings.keys()):
            fieldname=entity_mappings[token]
            lucene_query= lucene_query + fieldname + ":" + token + " "
            temp=""

        elif (token!=None and token!=" " and token!="" and token  in ['and','AND','or','OR','NOT','not']):
            lucene_query = lucene_query + token.upper() + " "
        else:
            if(token!=None and token!=" " and token!=""):
                temp=token
        print(" lucene query= ",lucene_query)

    print("lucene_query...",lucene_query)
    return lucene_query
