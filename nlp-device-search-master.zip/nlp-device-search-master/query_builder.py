from elasticsearch import Elasticsearch
from elasticsearch_dsl import Search
from elasticsearch_dsl import Q


client = Elasticsearch(["10.164.3.35"])

def build_match_queries(entities):
    match_queries = []
    for ent in entities:
        print("entity = ",ent)
        for value in entities[ent]:
            print(value)
            print(value['value'])
            # match_queries.append(Q('match',query=value['value'],field='_all',operator='and'))
            match_queries.append(Q('multi_match',query=value['value'],fields='_all',operator='and'))

    return match_queries

# def build_wildcard_queries(entities):
#     wildcard_queries = []
#     for entity in entities:
#         wildcard_queries.append(Q('wildcard',fields='_all'))




def build_search_query(entities):
    print("entities=",entities)
    s = Search(using=client, index="devices")
    print("Search client",s)
    queries = build_match_queries(entities)
    # queries.append(build_wildcard_queries(entities))
    print(queries)
    s.query = Q('bool',must=queries)
    response = s.execute()

    print(response)
    print(response.to_dict())
    return response.to_dict()['hits']

