import requests
import json
from flask import Flask
from flask import request
import os

def es_search(query):
    print("hello")
    uri = "http://10.164.3.35:9200/devices/_search?"
    # query=""
    # # term = "10.110"
    # params=request.args
    # query=""

    # if('query' in params):
    #     query=params.get('query')
        
    # print(params)
    # print("query",query)
    term=query
    term1=term+"*"
    inputs = { "query":
 { "bool":
 {"should":
 [{"match": {
			"_all": {
				"query":term,
                "operator":"and"  }    }},
        {"wildcard": {
            "_all": {
                "value": term1
            }}}]
 }
	
}	
}
    # query = json.dumps(inputs)
    # print(query)
    x = requests.get(uri,json=inputs)
    print(x.status_code)
    print(x.json())
    results="hello"
    # if x!=None:
    #     results = json.loads(json.loads(json.dumps(x)))
    #     print(results)
    return x.text


def direct_search(query):
    uri = "http://10.164.3.35:9200/devices/_search?"
    # entity="10.110"
    # query=""
    # term = "10.110"
    # params=request.args
    # query=""

    # if('query' in params):
    #     query=params.get('query')
        
    # print(params)
    # print("query",query)
    entity=query
    inputs = { "query":
{"match": {
			"_all": {
				"query":entity  }    }}}
    x = requests.get(uri,json=inputs)
    if (x.json()['hits']['total'])==0:
        y_resp = wildcard_search(entity)
        return y_resp
    return x.text

def wildcard_search(entity):
    wildcard=entity+"*"
    uri = "http://10.164.3.35:9200/devices/_search?"
    inputs= { "query": {"wildcard": {
            "_all": {
                "value": wildcard
            }}}}
    y = requests.get(uri,json=inputs)
    return y.text
    

