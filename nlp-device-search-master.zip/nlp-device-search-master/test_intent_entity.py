import requests

def execute_watson_api(text):
    URL="http://0.0.0.0:5000/nlpsearchquery"
    headers = {
    'Content-Type': 'application/json',
    }
    data = '{"input": "running-config:ospf "}'
    response = requests.post(URL, headers=headers, data=data)
