import re
def validateLuceneQuery(query):
    
    if(query != None and len(query) > 0):

        # query = removeEscapes(query)
        
        # check for allowed characters
        if(not checkAllowedCharacters(query)):
            return False      
        #check * is used properly
        if( not checkAsterisk(query)):
            return False      
        # check for && usage
        if( not checkAmpersands(query)):
            return False        
        # check ^ is used properly 
        # if(not checkCaret(query)):
        #     return False       
        # check ~ is used properly
        # if(not checkSquiggle(query)):
        #     return False       
        # check ! is used properly 
        if(not checkExclamationMark(query)):
            return False     
        # check question marks are used properly
        if(not checkQuestionMark(query)):
            return False 
        # check parentheses are used properly
        if(not checkParentheses(query)):
            return False 
        # check '+' and '-' are used properly      
        if(not checkPlusMinus(query)):
            return False 
        # check AND, OR and NOT are used properly
        if(not checkANDORNOT(query)):
            return False    
        # check that quote marks are closed
        if(not checkQuotes(query)):
            return False
        # check ':' is used properly
        if(not checkColon(query)):
            return False
        # if(wildcardCaseInsensitive)
        # {
        #   if(query.indexOf("*") != -1)
        #   {
        #     var i = query.indexOf(':');
        #     if(i == -1)
        #     {
        #       query.value = query.toLowerCase();
        #     }
        #     else // found a wildcard field search
        #     {
        #       query.value = query.substring(0, i) + query.substring(i).toLowerCase();
        #     }
        #   }
        # }
        return True



# def removeEscapes(query):
# {
#   return query.replace(/\\./g, "");
# }

def checkAllowedCharacters(query):
    matches = re.search('[^a-zA-Z0-9_+\-:.()\"*?&|!{}\[\]\^~\\@#\/$%\'= ]',query)

    if(matches != None and matches):
        print("Invalid search query! The allowed characters are a-z A-Z 0-9.  _ + - : () \" & * ? | ! {} [ ] ^ ~ \\ @ = # % $ ' /. Please try again.")
        return False
    print("Pass allowed characters")
    return True


def checkAsterisk(query):
    matches = re.search('^[\*]*$|[\s]\*|^\*[^\s]',query)
    if(matches != None and matches):
        print("Invalid search query! The wildcard (*) character must be preceded by at least one alphabet or number. Please try again.")
        return False
    print("passed asterisk")
    return True


def checkAmpersands(query):
    matches = re.search('[&]{2}',query)
    if(matches != None and matches):
        matches=re.search('^([a-zA-Z0-9_+\-:.()\"*?&|!{}\[\]\^~\\@#\/$%\'=]+( && )?[a-zA-Z0-9_+\-:.()\"*?|!{}\[\]\^~\\@#\/$%\'=]+[ ]*)+$') 
        if(matches == None):
            print("Invalid search query! Queries containing the special characters && must be in the form: term1 && term2. Please try again.")
            return False
    print("passed ampersands")
    return True


def checkCaret(query):
    matches = re.search('[^\\]\^([^\s]*[^0-9.]+)|[^\\]\^$',query)
    if(matches != None):
        print("Invalid search query! The caret (^) character must be preceded by alphanumeric characters and followed by numbers. Please try again.")
        return False
    print("pass caret")
    return True


def checkSquiggle(query):
    matches = re.search('[^\\]~[^\s]*[^0-9\s]+',query)
    if(matches != None):
        print("Invalid search query! The tilde (~) character must be preceded by alphanumeric characters and followed by numbers. Please try again.")
        return False  
    print("passed squiggle")
    return True


def checkExclamationMark(query):
    matches = re.search('^[^!]*$|^([a-zA-Z0-9_+\-:.()\"*?&|!{}\[\]\^~\\@#\/$%\'=]+( ! )?[a-zA-Z0-9_+\-:.()\"*?&|!{}\[\]\^~\\@#\/$%\'=]+[ ]*)+$',query)
    if(matches == None or (not matches)):
        print("Invalid search query! Queries containing the special character ! must be in the form: term1 ! term2. Please try again.")
        return False
    print("passed exclamation")
    return True


def checkQuestionMark(query):
    matches = re.search('^(\?)|([^a-zA-Z0-9_+\-:.()\"*?&|!{}\[\]\^~\\@#\/$%\'=]\?+)',query)
    if(matches != None and matches):
        print("Invalid search query! The question mark (?) character must be preceded by at least one alphabet or number. Please try again.")
        return False
    print("passed question mark")
    return True

def checkParentheses(query):
    hasLeft = False
    hasRight = False
    matchLeft = re.findall('[(]',query)
    if(matchLeft != None):
         hasLeft = True
    matchRight = re.findall('[)]',query)
    if(matchRight != None):
         hasRight = True
    
    if(hasLeft or hasRight):
        if(hasLeft and  (not hasRight) or hasRight and (not hasLeft)):
            print("Invalid search query! Parentheses must be closed. Please try again.")
            return False
        else:
            number = len(matchLeft)+ len(matchRight)
            if((number % 2) > 0 or len(matchLeft) != len(matchRight)):
                print("Invalid search query! Parentheses must be closed. Please try again.")
                return False
        matches = re.search('\(\)',query)
        if(matches != None):
            print("Invalid search query! Parentheses must contain at least one character. Please try again.")
            return False   
    print("passed paranthesis check")  
    return True

def checkPlusMinus(query):
    matches = re.search('^[^\n+\-]*$|^([+-]?[a-zA-Z0-9_:.()\"*?&|!{}\[\]\^~\\@#\/$%\'=]+[ ]?)+$',query)
    if(matches == None or not matches):
        print("Invalid search query! '+' and '-' modifiers must be followed by at least one alphabet or number. Please try again.")
        return False
    print("passed plus minus")
    return True

def checkANDORNOT(query):
    matches = re.search('AND|OR|NOT',query)
    if(matches != None and matches):
        matches = re.search('^([a-zA-Z0-9_+\-:.()\"*?&|!{}\[\]\^~\\@\/#$%\'=]+\s*((AND )|(OR )|(AND NOT )|(NOT ))?[a-zA-Z0-9_+\-:.()\"*?&|!{}\[\]\^~\\@\/#$%\'=]+[ ]*)+$',query);       
        if(matches == None or not matches):
            print("Invalid search query!  Queries containing AND/OR/NOT must be in the form: term1 AND|OR|NOT|AND NOT term2 Please try again.")
            return False
        
        matches = re.search('^((AND )|(OR )|(AND NOT )|(NOT ))|((AND)|(OR)|(AND NOT )|(NOT))[ ]*$',query)
        if(matches != None and matches):
            print("Invalid search query!  Queries containing AND/OR/NOT must be in the form: term1 AND|OR|NOT|AND NOT term2 Please try again.")
            return False
    print("passed boolean expression AND OR nOT check")
    return True


def checkQuotes(query):

    matches = re.findall('\"',query)
    if(matches != None and len(matches)>0):
        number = len(matches)
        if((number % 2) > 0):
            print("Invalid search query! Please close all quote (\") marks.")
            return False
        matches = query.match('\"\"')
        if(matches != None):
            print("Invalid search query! Quotes must contain at least one character. Please try again.")
            return False 
    print("passed quotes") 
    return True


def checkColon(query):

  matches = re.search('[^\\\s]:[\s]|[^\\\s]:$|[\s][^\\]?:|^[^\\\s]?:',query)
  if(matches != None):
      print("Invalid search query! Field declarations (:) must be preceded by at least one alphabet or number and followed by at least one alphabet or number. Please try again.")
      return False
  print("passed colons")
  return True


# testquery="helloword!:haha"
# print(validateLuceneQuery(testquery)