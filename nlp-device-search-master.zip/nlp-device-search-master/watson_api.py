import os
import json
import traceback
import configparser as ConfigParser
import time
import requests
import logging as log
# from jupiter.logger import logging
from watson_developer_cloud import AssistantV1
from watson_developer_cloud import WatsonApiException
from flask_login import login_required, current_user
from pprint import pprint
import logging

log = logging.getLogger()

"""
Call Watson Assistant API service and get the response.
"""
config = ConfigParser.ConfigParser()
# config.read('/home/config.ini')
config.read('/ws/datarp/nlpdevicesearch/config.ini')



def get_assistant_response(message):
    try:
        log.info("test in watson")
        watson_assistant = AssistantV1(
            version = config.get('ASSISTANT','ASSIST_VERSION'),
            iam_apikey = config.get('ASSISTANT','ASSIST_IAMAPIKEY'),
            url = config.get('ASSISTANT','ASSIST_URL')
        )
        watson_assistant.set_http_config({'timeout' : 3})

        workspaces = watson_assistant.list_workspaces().get_result()
        workspace_id = config.get('ASSISTANT','ASSIST_WORKSPACEID')

        wk_spaces= []
        for item in workspaces['workspaces']:
            wk_spaces.append(item['workspace_id'])

        if workspace_id not in wk_spaces:
            raise Exception('Invalid Workspace ID given!')

    except WatsonApiException as ex:
        log.error('Method failed with status code ' + str(ex.code) + ': ' + ex.message)

    else:
        start = time.time()
        log.info('Starting Assistant task')
        try:
            log.info("Calling watson assistant api")
            log.info(watson_assistant)
            response = watson_assistant.message(
                    workspace_id=workspace_id,
                    input = {
                        'text': message
                    },
                    alternate_intents = True,
                    # context = {
                    #     'metadata': {
                    #         'user_id': userInfo.get('name')
                    #     }
                    # }
                )
        except requests.exceptions.ReadTimeout as err:
            log.error('Read timeout error : {}'.format(err))
        else:
            pprint(response.result, indent = 4)
            end = time.time()
            log.info('Assistant Execution time : {}\n'.format(end-start))
            return json.dumps(response.result)
        return